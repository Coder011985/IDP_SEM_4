<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Default Broadcaster
    |--------------------------------------------------------------------------
    */

    'default' => env('BROADCAST_CONNECTION', 'reverb'),

    /*
    |--------------------------------------------------------------------------
    | Broadcast Connections
    |--------------------------------------------------------------------------
    */

    'connections' => [

        /*
        |--------------------------------------------------------------------------
        | Laravel Reverb (Recommended - Free WebSocket)
        |--------------------------------------------------------------------------
        */

        'reverb' => [
            'driver' => 'reverb',
            'key' => env('REVERB_APP_KEY'),
            'secret' => env('REVERB_APP_SECRET'),
            'app_id' => env('REVERB_APP_ID'),

            'options' => [
                'host' => env('REVERB_HOST', '127.0.0.1'),
                'port' => env('REVERB_PORT', 8080),
                'scheme' => env('REVERB_SCHEME', 'http'),
                'useTLS' => env('REVERB_SCHEME', 'http') === 'https',
            ],

            'client_options' => [],
        ],

        /*
        |--------------------------------------------------------------------------
        | Pusher (Cloud alternative)
        |--------------------------------------------------------------------------
        */

        'pusher' => [
            'driver' => 'pusher',
            'key' => env('PUSHER_APP_KEY'),
            'secret' => env('PUSHER_APP_SECRET'),
            'app_id' => env('PUSHER_APP_ID'),

            'options' => [
                'cluster' => env('PUSHER_APP_CLUSTER'),
                'host' => env('PUSHER_HOST', 'api-' . env('PUSHER_APP_CLUSTER', 'mt1') . '.pusher.com'),
                'port' => env('PUSHER_PORT', 443),
                'scheme' => env('PUSHER_SCHEME', 'https'),
                'encrypted' => true,
                'useTLS' => env('PUSHER_SCHEME', 'https') === 'https',
            ],

            'client_options' => [],
        ],

        /*
        |--------------------------------------------------------------------------
        | Ably (Optional)
        |--------------------------------------------------------------------------
        */

        'ably' => [
            'driver' => 'ably',
            'key' => env('ABLY_KEY'),
        ],

        /*
        |--------------------------------------------------------------------------
        | Log Driver (Debugging)
        |--------------------------------------------------------------------------
        */

        'log' => [
            'driver' => 'log',
        ],

        /*
        |--------------------------------------------------------------------------
        | Null Driver
        |--------------------------------------------------------------------------
        */

        'null' => [
            'driver' => 'null',
        ],

    ],

];
