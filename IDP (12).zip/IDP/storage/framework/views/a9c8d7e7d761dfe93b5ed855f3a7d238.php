<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_','-',app()->getLocale())); ?>">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $__env->yieldContent('title','Designer Panel'); ?> - IDP</title>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

</head>


<body class="bg-slate-100">

<div class="flex h-screen overflow-hidden">



<aside class="w-64 bg-white border-r flex-shrink-0">

<?php echo $__env->make('layouts.sidebar-designer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</aside>




<div class="flex-1 flex flex-col overflow-hidden">



<header class="bg-white border-b px-8 py-4 flex items-center justify-between">

<h1 class="text-xl font-semibold text-slate-800">
<?php echo $__env->yieldContent('title','Designer Dashboard'); ?>
</h1>


<div class="flex items-center gap-6">

<span class="text-sm text-gray-600">
<?php echo e(auth()->user()->name ?? ''); ?>

</span>

<a href="<?php echo e(route('profile.edit')); ?>"
class="text-sm text-blue-600 hover:text-blue-700">
Profile
</a>

<form method="POST" action="<?php echo e(route('logout')); ?>">
<?php echo csrf_field(); ?>

<button class="text-red-500 hover:text-red-600 text-sm">
Logout
</button>

</form>

</div>

</header>




<main class="flex-1 overflow-y-auto p-8">

<div class="max-w-7xl mx-auto">

<?php if(session('success')): ?>
<div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="mb-4 p-3 bg-red-100 text-red-700 rounded">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</div>

</main>


</div>

</div>

</body>
</html>
<?php /**PATH C:\wamp64\www\IDP\resources\views/layouts/designer.blade.php ENDPATH**/ ?>