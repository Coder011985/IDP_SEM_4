<?php $__env->startSection('title','Client Dashboard'); ?>

<?php $__env->startSection('content'); ?>

<div class="flex justify-between items-center mb-8">

    <h1 class="text-2xl font-bold">
        Client Dashboard
    </h1>

    <a href="<?php echo e(route('client.projects.create')); ?>"
       class="bg-blue-600 text-white px-5 py-2 rounded-lg hover:bg-blue-700 transition">

        + Create Project

    </a>

</div>






<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

    <div class="bg-white p-6 rounded-xl shadow border">

        <p class="text-gray-500 text-sm">
            Total Projects
        </p>

        <h2 class="text-3xl font-bold mt-2">
            <?php echo e($total ?? 0); ?>

        </h2>

    </div>


    <div class="bg-white p-6 rounded-xl shadow border">

        <p class="text-gray-500 text-sm">
            Pending Projects
        </p>

        <h2 class="text-3xl font-bold mt-2">
            <?php echo e($pending ?? 0); ?>

        </h2>

    </div>


    <div class="bg-white p-6 rounded-xl shadow border">

        <p class="text-gray-500 text-sm">
            Completed Projects
        </p>

        <h2 class="text-3xl font-bold mt-2">
            <?php echo e($completed ?? 0); ?>

        </h2>

    </div>

</div>







<div class="bg-white rounded-xl shadow border">

    <div class="p-6 border-b">

        <h2 class="text-lg font-semibold">
            Recent Projects
        </h2>

    </div>


    <div class="overflow-x-auto">

        <table class="w-full text-left">

            <thead class="bg-gray-50 text-sm text-gray-600">

                <tr>
                    <th class="p-4">Title</th>
                    <th class="p-4">Status</th>
                    <th class="p-4">Budget</th>
                    <th class="p-4">Deadline</th>
                    <th class="p-4">Action</th>
                </tr>

            </thead>


            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $recentProjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                <tr class="border-t">

                    <td class="p-4 font-medium">
                        <?php echo e($project->title); ?>

                    </td>


                    <td class="p-4">

                        <span class="px-3 py-1 text-sm rounded bg-gray-100">
                            <?php echo e(ucfirst($project->status)); ?>

                        </span>

                    </td>


                    <td class="p-4">
                        ₹<?php echo e(number_format($project->budget_min ?? 0)); ?> -
                        ₹<?php echo e(number_format($project->budget_max ?? 0)); ?>

                    </td>


                    <td class="p-4">
                        <?php echo e($project->deadline ? $project->deadline->format('d M Y') : '-'); ?>

                    </td>


                    <td class="p-4">

                        <a href="<?php echo e(route('client.projects.show', $project->id)); ?>"
                           class="text-blue-600 hover:underline">

                           View

                        </a>

                    </td>

                </tr>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                <tr>

                    <td colspan="5" class="p-6 text-center text-gray-500">

                        No projects found

                    </td>

                </tr>

            <?php endif; ?>

            </tbody>

        </table>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/client/dashboard.blade.php ENDPATH**/ ?>