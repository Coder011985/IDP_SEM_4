<?php $__env->startSection('title','My Earnings'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto space-y-8">

<h1 class="text-2xl font-bold">
My Earnings
</h1>




<div class="grid grid-cols-1 md:grid-cols-2 gap-6">

<div class="bg-green-100 p-6 rounded-xl shadow">
<p class="text-sm text-green-700">
Total Released Earnings
</p>

<p class="text-2xl font-bold text-green-900 mt-2">
₹<?php echo e(number_format($releasedTotal,2)); ?>

</p>
</div>


<div class="bg-yellow-100 p-6 rounded-xl shadow">
<p class="text-sm text-yellow-700">
Escrow (Funded)
</p>

<p class="text-2xl font-bold text-yellow-900 mt-2">
₹<?php echo e(number_format($fundedTotal,2)); ?>

</p>
</div>

</div>




<div class="bg-white rounded-xl shadow overflow-hidden">

<table class="w-full text-left">

<thead class="bg-gray-50 text-xs uppercase text-gray-500">

<tr>
<th class="px-6 py-3">Project</th>
<th class="px-6 py-3">Client</th>
<th class="px-6 py-3">Amount</th>
<th class="px-6 py-3">Status</th>
<th class="px-6 py-3">Released</th>
</tr>

</thead>


<tbody class="divide-y">

<?php $__empty_1 = true; $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<tr class="hover:bg-gray-50">

<td class="px-6 py-4 text-sm font-medium">
<?php echo e($payment->project->title ?? '-'); ?>

</td>

<td class="px-6 py-4 text-sm">
<?php echo e($payment->project->client->name ?? '-'); ?>

</td>

<td class="px-6 py-4 text-sm font-semibold">
₹<?php echo e(number_format($payment->amount,2)); ?>

</td>

<td class="px-6 py-4 text-sm">

<?php
$color = match($payment->status){
'released'=>'bg-green-100 text-green-700',
'funded'=>'bg-yellow-100 text-yellow-700',
default=>'bg-gray-100 text-gray-700'
};
?>

<span class="px-2 py-1 text-xs rounded <?php echo e($color); ?>">
<?php echo e(ucfirst($payment->status)); ?>

</span>

</td>

<td class="px-6 py-4 text-sm text-gray-600">

<?php echo e($payment->released_at
? \Carbon\Carbon::parse($payment->released_at)->format('d M Y')
: '-'); ?>


</td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<tr>
<td colspan="5" class="text-center py-6 text-gray-500">
No earnings yet.
</td>
</tr>

<?php endif; ?>

</tbody>

</table>

</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.designer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/designer/earnings.blade.php ENDPATH**/ ?>