<!DOCTYPE html>

<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title><?php echo $__env->yieldContent('title','Client Panel'); ?> - IDP</title>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

</head>

<body class="bg-slate-100">

<div class="flex h-screen overflow-hidden">


<aside class="w-64 bg-white border-r flex-shrink-0">

<?php echo $__env->make('layouts.sidebar-client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</aside>




<div class="flex-1 flex flex-col overflow-hidden">




<header class="bg-white border-b px-8 py-4 flex items-center justify-between">

<h1 class="text-xl font-semibold text-slate-800">
<?php echo $__env->yieldContent('title','Dashboard'); ?>
</h1>

<div class="flex items-center gap-6">

<?php

$notifications = auth()->check()
? \App\Models\Notification::where('user_id', auth()->id())
->latest()
->take(5)
->get()
: collect();

$notificationCount = auth()->check()
? auth()->user()->unreadNotificationsCount()
: 0;

$chatUnread = auth()->check()
? \App\Models\Chat::unreadCountForUser(auth()->id())
: 0;

?>




<div class="relative">

<a href="<?php echo e(route('client.projects.index')); ?>"
class="relative text-gray-600 hover:text-gray-800">

💬

<?php if($chatUnread > 0): ?>
<span
class="absolute -top-2 -right-3 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
<?php echo e($chatUnread); ?>

</span>
<?php endif; ?>

</a>

</div>




<div class="relative">

<button onclick="toggleNotifications()"
class="relative text-gray-600 hover:text-gray-800">

🔔

<?php if($notificationCount > 0): ?>
<span
class="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
<?php echo e($notificationCount); ?>

</span>
<?php endif; ?>

</button>



<div id="notificationDropdown"
class="hidden absolute right-0 mt-3 w-80 bg-white border rounded-lg shadow-lg z-50">

<div class="p-3 border-b font-semibold text-sm">
Notifications
</div>

<div class="max-h-80 overflow-y-auto">

<?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<a href="<?php echo e($notification->link ?? route('notifications.index')); ?>"
class="block px-4 py-3 text-sm hover:bg-gray-100
<?php echo e($notification->is_read ? '' : 'bg-blue-50'); ?>">

<?php echo e($notification->message); ?>


<div class="text-xs text-gray-500 mt-1">
<?php echo e($notification->created_at->diffForHumans()); ?>

</div>

</a>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<div class="p-4 text-sm text-gray-500 text-center">
No notifications
</div>

<?php endif; ?>

</div>

<div class="p-2 border-t text-center">
<a href="<?php echo e(route('notifications.index')); ?>"
class="text-sm text-blue-600 hover:underline">
View all notifications
</a>
</div>

</div>

</div>




<span class="text-sm text-gray-600">
<?php echo e(Auth::user()->name ?? ''); ?>

</span>




<a href="<?php echo e(route('profile.edit')); ?>"
class="text-blue-600 hover:text-blue-700 text-sm">
Profile
</a>




<form method="POST" action="<?php echo e(route('logout')); ?>">
<?php echo csrf_field(); ?>
<button class="text-red-500 hover:text-red-600 text-sm">
Logout
</button>
</form>

</div>

</header>




<main class="flex-1 overflow-y-auto p-8">

<div class="max-w-7xl mx-auto">

<?php if(session('success')): ?>
<div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="mb-4 p-3 bg-red-100 text-red-700 rounded">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>

<?php echo $__env->yieldContent('content'); ?>

</div>

</main>

</div>

</div>


<script>

function toggleNotifications() {
const dropdown = document.getElementById('notificationDropdown');
dropdown.classList.toggle('hidden');
}

</script>

</body>
</html>
<?php /**PATH C:\wamp64\www\IDP\resources\views/layouts/client.blade.php ENDPATH**/ ?>