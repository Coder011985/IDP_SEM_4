<nav class="flex flex-col h-full bg-white border-r p-6">


<div class="mb-10">

<h1 class="text-xl font-bold text-slate-800">
IDP Designer
</h1>

<p class="text-sm text-gray-500 mt-1">
Interior Design Portal
</p>

</div>




<div class="space-y-2 flex-1">



<a href="<?php echo e(route('designer.projects')); ?>"
class="flex items-center px-4 py-2 rounded-lg transition
<?php echo e(request()->routeIs('designer.projects') && !request()->routeIs('designer.projects.assigned') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-blue-50 text-slate-700'); ?>">
Dashboard
</a>



<a href="<?php echo e(route('designer.projects.assigned')); ?>"
class="flex items-center px-4 py-2 rounded-lg transition
<?php echo e(request()->routeIs('designer.projects.assigned') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-blue-50 text-slate-700'); ?>">
Assigned Projects
</a>



<a href="<?php echo e(route('designer.portfolio.index')); ?>"
class="flex items-center px-4 py-2 rounded-lg transition
<?php echo e(request()->routeIs('designer.portfolio.*') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-blue-50 text-slate-700'); ?>">
Portfolio
</a>



<a href="<?php echo e(route('designer.earnings')); ?>"
class="flex items-center px-4 py-2 rounded-lg transition
<?php echo e(request()->routeIs('designer.earnings') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-blue-50 text-slate-700'); ?>">
My Earnings
</a>



<?php
$unread = auth()->check()
? auth()->user()->unreadNotificationsCount()
: 0;
?>

<a href="<?php echo e(route('notifications.index')); ?>"
class="flex items-center justify-between px-4 py-2 rounded-lg transition
<?php echo e(request()->routeIs('notifications.*') ? 'bg-blue-100 text-blue-700 font-semibold' : 'hover:bg-blue-50 text-slate-700'); ?>">

<span>Notifications</span>

<?php if($unread > 0): ?>
<span class="bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
<?php echo e($unread); ?>

</span>
<?php endif; ?>

</a>

</div>




<div class="border-t pt-6">

<p class="text-sm text-gray-600 mb-3">
<?php echo e(auth()->user()->name ?? ''); ?>

</p>

</div>

</nav>
<?php /**PATH C:\wamp64\www\IDP\resources\views/layouts/sidebar-designer.blade.php ENDPATH**/ ?>