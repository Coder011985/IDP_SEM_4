<?php $__env->startSection('title','My Portfolio'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

<div class="flex justify-between items-center mb-6">

<h2 class="text-2xl font-bold">My Portfolio</h2>

<a href="<?php echo e(route('designer.portfolio.create')); ?>"
class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
Add Portfolio
</a>

</div>


<?php if(session('success')): ?>
<div class="bg-green-100 text-green-700 p-3 rounded mb-4">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>



<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">

<?php $__empty_1 = true; $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="bg-white shadow rounded-lg overflow-hidden">

<?php if($portfolio->images->first() && $portfolio->images->first()->image_path): ?>
<img src="<?php echo e(asset('storage/'.$portfolio->images->first()->image_path)); ?>"
class="w-full h-48 object-cover">
<?php endif; ?>


<div class="p-4">

<h3 class="font-semibold text-lg">
<?php echo e($portfolio->title); ?>

</h3>

<p class="text-sm text-gray-500 mb-2">
<?php echo e($portfolio->category); ?>

</p>

<p class="text-gray-600 text-sm mb-4">
<?php echo e(\Illuminate\Support\Str::limit($portfolio->description,100)); ?>

</p>


<div class="flex justify-between items-center">

<a href="<?php echo e(route('designer.portfolio.edit',$portfolio->id)); ?>"
class="text-blue-600 hover:underline text-sm">
Edit
</a>

<form method="POST"
action="<?php echo e(route('designer.portfolio.destroy',$portfolio->id)); ?>">

<?php echo csrf_field(); ?>
<?php echo method_field('DELETE'); ?>

<button
onclick="return confirm('Delete this portfolio project?')"
class="text-red-600 hover:underline text-sm">
Delete
</button>

</form>

</div>

</div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<div class="col-span-full text-center text-gray-500 py-16">
No portfolio projects yet.
</div>

<?php endif; ?>

</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.designer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/designer/portfolio/index.blade.php ENDPATH**/ ?>