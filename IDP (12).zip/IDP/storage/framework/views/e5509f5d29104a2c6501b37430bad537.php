<?php $__env->startSection('title','Assigned Projects'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto space-y-8">

<div>

<h2 class="text-2xl font-bold">
Assigned Projects
</h2>

<p class="text-sm text-slate-500">
Manage milestones and submit work.
</p>

</div>



<?php if(session('success')): ?>
<div class="p-4 bg-green-100 text-green-700 rounded-lg">
<?php echo e(session('success')); ?>

</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="p-4 bg-red-100 text-red-700 rounded-lg">
<?php echo e(session('error')); ?>

</div>
<?php endif; ?>



<div class="space-y-8">

<?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php
$completion = $project->calculateProgress();
$escrow = $project->escrowAmount();
$released = $project->releasedAmount();
?>


<div class="bg-white rounded-xl shadow p-6">

<div class="flex justify-between items-start mb-4">

<div>

<h3 class="text-lg font-semibold">
<?php echo e($project->title); ?>

</h3>

<p class="text-sm text-slate-500">
<?php echo e(\Illuminate\Support\Str::limit($project->description,100)); ?>

</p>

</div>

<div class="flex items-center gap-3">

<a
href="<?php echo e(route('designer.projects.chat',$project)); ?>"
class="px-4 py-2 text-sm bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg">
Chat
</a>

<span class="px-3 py-1 text-xs rounded-full bg-blue-100 text-blue-700">
<?php echo e(ucfirst($project->status)); ?>

</span>

</div>

</div>




<div class="grid grid-cols-2 md:grid-cols-3 gap-4 mb-6 text-sm">

<div class="bg-slate-50 p-3 rounded-lg">
<p class="text-slate-500">Escrow</p>
<p class="font-semibold text-blue-600">
₹<?php echo e(number_format($escrow,2)); ?>

</p>
</div>

<div class="bg-slate-50 p-3 rounded-lg">
<p class="text-slate-500">Released</p>
<p class="font-semibold text-emerald-600">
₹<?php echo e(number_format($released,2)); ?>

</p>
</div>

<div class="bg-slate-50 p-3 rounded-lg">
<p class="text-slate-500">Milestones</p>
<p class="font-semibold">
<?php echo e($project->milestones->count()); ?>

</p>
</div>

</div>




<div class="mb-6">

<div class="flex justify-between text-sm mb-1">

<span>Completion</span>

<span class="font-semibold">
<?php echo e($completion); ?>%
</span>

</div>

<div class="w-full bg-slate-200 rounded-full h-3">

<div
class="bg-emerald-500 h-3 rounded-full"
style="width: <?php echo e($completion); ?>%">
</div>

</div>

</div>




<div class="space-y-4">

<?php $__empty_2 = true; $__currentLoopData = $project->milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $milestone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>

<?php
$badge = match($milestone->status){
'pending'=>'bg-amber-100 text-amber-700',
'funded'=>'bg-blue-100 text-blue-700',
'approved'=>'bg-indigo-100 text-indigo-700',
'released'=>'bg-emerald-100 text-emerald-700',
default=>'bg-slate-100 text-slate-700'
};
?>


<div class="border rounded-lg p-4">

<div class="flex justify-between items-center mb-2">

<h4 class="font-semibold">
<?php echo e($milestone->title); ?>

</h4>

<span class="px-3 py-1 text-xs rounded-full <?php echo e($badge); ?>">
<?php echo e(ucfirst($milestone->status)); ?>

</span>

</div>

<p class="text-sm text-slate-600 mb-2">
Amount: ₹<?php echo e(number_format($milestone->amount,2)); ?>

</p>



<?php if($milestone->status === 'funded'): ?>

<form
method="POST"
action="<?php echo e(route('designer.projects.completeMilestone',[$project->id,$milestone->id])); ?>">

<?php echo csrf_field(); ?>

<button
class="bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg text-sm">
Submit Milestone
</button>

</form>

<?php endif; ?>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>

<p class="text-sm text-slate-500">
No milestones yet.
</p>

<?php endif; ?>

</div>

</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

<div class="text-center p-10 border border-dashed rounded-xl text-slate-500">
No assigned projects.
</div>

<?php endif; ?>

</div>



<div class="mt-8">
<?php echo e($projects->links()); ?>

</div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.designer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/designer/assigned_projects.blade.php ENDPATH**/ ?>