<?php $__env->startSection('title','Notifications'); ?>

<?php $__env->startSection('content'); ?>

<div class="max-w-4xl mx-auto space-y-6">

    
    <div class="bg-white shadow rounded-lg p-5 flex items-center justify-between">

        <div>
            <h2 class="text-lg font-semibold">
                Notifications
            </h2>

            <p class="text-xs text-gray-500">
                Unread: <?php echo e($unreadCount ?? 0); ?>

            </p>
        </div>

        
        <?php if(($unreadCount ?? 0) > 0): ?>
        <form method="POST" action="<?php echo e(route('notifications.readAll')); ?>">
            <?php echo csrf_field(); ?>

            <button
                class="text-sm bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700 transition">
                Mark All Read
            </button>
        </form>
        <?php endif; ?>

    </div>


    
    <div class="bg-white shadow rounded-lg divide-y">

        <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <div class="p-5 flex justify-between items-center
            <?php echo e($notification->is_read ? 'bg-white' : 'bg-blue-50'); ?>">

            <div class="flex-1">

                <p class="text-gray-800">
                    <?php echo e($notification->message); ?>

                </p>

                <p class="text-xs text-gray-500 mt-1">
                    <?php echo e(optional($notification->created_at)->diffForHumans()); ?>

                </p>

            </div>


            <div class="flex items-center gap-4">

                
                <?php if($notification->link): ?>
                <a href="<?php echo e($notification->link); ?>"
                   class="text-sm text-blue-600 hover:underline">
                    Open
                </a>
                <?php endif; ?>


                
                <?php if(!$notification->is_read): ?>

                <form method="POST"
                      action="<?php echo e(route('notifications.read',$notification)); ?>">
                    <?php echo csrf_field(); ?>

                    <button class="text-sm text-blue-600 hover:underline">
                        Mark read
                    </button>

                </form>

                <?php endif; ?>

            </div>

        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div class="p-6 text-center text-gray-500">
            No notifications yet
        </div>

        <?php endif; ?>

    </div>


    
    <?php if(method_exists($notifications,'links')): ?>
    <div>
        <?php echo e($notifications->links()); ?>

    </div>
    <?php endif; ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(
auth()->user()->role === 'designer'
    ? 'layouts.designer'
    : (auth()->user()->role === 'client'
        ? 'layouts.client'
        : 'layouts.admin')
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/notifications/index.blade.php ENDPATH**/ ?>