<?php $__env->startSection('title','My Projects'); ?>

<?php $__env->startSection('content'); ?>

<?php
use Illuminate\Support\Str;
?>

<div class="max-w-7xl mx-auto space-y-8">


<div class="flex items-center justify-between">

<h2 class="text-2xl font-bold text-slate-800">
My Projects
</h2>

<a href="<?php echo e(route('client.projects.create')); ?>"
class="px-5 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition">
Create Project
</a>

</div>




<div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-2 gap-6">

<?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<?php

$status = $project->status ?? 'pending';

$statusClasses = match($status) {
'pending' => 'bg-amber-100 text-amber-700',
'assigned' => 'bg-blue-100 text-blue-700',
'completed' => 'bg-green-100 text-green-700',
default => 'bg-slate-100 text-slate-700',
};

$progress = $project->milestoneCompletionPercentage();
$escrow = $project->escrowAmount();
$released = $project->releasedAmount();

$lastMessage = $project->lastMessage();

$unreadCount = $project->designer_id
    ? $project->unreadMessagesCount(auth()->id())
    : 0;

?>


<div class="bg-white rounded-xl shadow hover:shadow-lg transition p-6 flex flex-col">


<div class="flex justify-between items-start mb-3">

<div>

<h3 class="text-lg font-semibold text-slate-800">
<?php echo e($project->title); ?>

</h3>

<?php if($project->designer): ?>

<div class="flex items-center gap-2 mt-1 text-sm text-slate-500">

<img
src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($project->designer->name)); ?>"
class="w-6 h-6 rounded-full">

<span>
<?php echo e($project->designer->name); ?>

</span>

</div>

<?php endif; ?>

</div>

<span class="px-3 py-1 text-xs rounded-full <?php echo e($statusClasses); ?>">
<?php echo e(ucfirst($status)); ?>

</span>

</div>




<p class="text-sm text-slate-600 mb-3">
<?php echo e(Str::limit($project->description,120)); ?>

</p>




<?php if($lastMessage): ?>

<div class="text-xs text-gray-500 mb-3 bg-gray-50 p-2 rounded">

💬 <?php echo e($project->chatPreview()); ?>


<span class="text-gray-400">
• <?php echo e($lastMessage->created_at->diffForHumans()); ?>

</span>

</div>

<?php endif; ?>




<p class="font-semibold text-slate-800 mb-4">
₹<?php echo e(number_format($project->budget_min)); ?>

-
₹<?php echo e(number_format($project->budget_max)); ?>

</p>




<div class="grid grid-cols-2 gap-4 mb-4 text-xs">

<div class="bg-slate-50 p-2 rounded">

<p class="text-slate-500">Escrow</p>

<p class="font-semibold text-blue-600">
₹<?php echo e(number_format($escrow,2)); ?>

</p>

</div>

<div class="bg-slate-50 p-2 rounded">

<p class="text-slate-500">Released</p>

<p class="font-semibold text-emerald-600">
₹<?php echo e(number_format($released,2)); ?>

</p>

</div>

</div>




<div class="mb-4">

<div class="flex justify-between text-sm mb-1">

<span class="text-slate-500">
Progress
</span>

<span class="font-semibold">
<?php echo e($progress); ?>%
</span>

</div>

<div class="w-full bg-gray-200 rounded-full h-2">

<div class="bg-emerald-500 h-2 rounded-full"
style="width: <?php echo e($progress); ?>%">
</div>

</div>

</div>




<div class="space-y-1 text-sm text-slate-600 mb-5">

<?php if($project->location): ?>
<p>📍 <?php echo e($project->location); ?></p>
<?php endif; ?>

<?php if($project->area_sqft): ?>
<p>📐 <?php echo e($project->area_sqft); ?> sq.ft</p>
<?php endif; ?>

<?php if($project->deadline): ?>
<p>⏳ <?php echo e(\Carbon\Carbon::parse($project->deadline)->format('d M Y')); ?></p>
<?php endif; ?>

<?php if($project->style): ?>
<p>🎨 <?php echo e($project->style); ?></p>
<?php endif; ?>

<?php if($project->property_type): ?>
<p>🏠 <?php echo e(ucfirst($project->property_type)); ?></p>
<?php endif; ?>

</div>




<div class="flex gap-3 mt-auto">

<a href="<?php echo e(route('client.projects.show',$project->id)); ?>"
class="flex-1 flex items-center justify-center h-10 bg-slate-800 hover:bg-black text-white rounded-lg text-sm font-medium transition">
View Project
</a>

<a href="<?php echo e(route('client.projects.bids',$project->id)); ?>"
class="flex-1 flex items-center justify-center h-10 bg-emerald-500 hover:bg-emerald-600 text-white rounded-lg text-sm font-medium transition">
View Bids
</a>

<?php if($project->designer_id): ?>

<a href="<?php echo e(route('client.projects.chat',$project->id)); ?>"
class="relative flex-1 flex items-center justify-center h-10 bg-blue-500 hover:bg-blue-600 text-white rounded-lg text-sm font-medium transition">

Chat

<?php if($unreadCount): ?>

<span class="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-2 py-0.5 rounded-full">
<?php echo e($unreadCount); ?>

</span>

<?php endif; ?>

</a>

<?php endif; ?>

</div>

</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>


<div class="col-span-2 bg-white p-12 rounded-xl shadow text-center">

<p class="text-slate-500 mb-4">
No projects yet.
</p>

<a href="<?php echo e(route('client.projects.create')); ?>"
class="px-5 py-3 bg-blue-600 text-white rounded-lg">
Create Project
</a>

</div>


<?php endif; ?>

</div>


<div>
<?php echo e($projects->links()); ?>

</div>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.client', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\IDP\resources\views/client/projects/index.blade.php ENDPATH**/ ?>