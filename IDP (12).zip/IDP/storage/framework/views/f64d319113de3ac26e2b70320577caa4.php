<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Interior Design Portal (IDP) – Hire Professional Interior Designers</title>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css','resources/js/app.js']); ?>

</head>

<body class="bg-gray-50 text-gray-900 flex flex-col min-h-screen">


<!-- ================= NAVBAR ================= -->

<header class="bg-white border-b sticky top-0 z-50">

<div class="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">

<div class="text-xl font-bold tracking-tight">
IDP
</div>

<nav class="flex items-center gap-6 text-sm font-medium text-gray-600">

<a href="/" class="hover:text-black">Home</a>

<a href="<?php echo e(route('public.designers.index')); ?>" class="hover:text-black">
Browse Designers
</a>

<a href="#features" class="hover:text-black">
Features
</a>

<a href="#workflow" class="hover:text-black">
How It Works
</a>

<?php if(auth()->guard()->check()): ?>

<span class="text-gray-500 hidden md:block">
<?php echo e(Auth::user()->name); ?>

</span>

<a href="<?php echo e(route('dashboard')); ?>"
class="bg-black text-white px-4 py-2 rounded-md hover:opacity-90">
Dashboard
</a>

<?php else: ?>

<a href="<?php echo e(route('login')); ?>" class="hover:text-black">
Login
</a>

<a href="<?php echo e(route('register')); ?>"
class="bg-black text-white px-4 py-2 rounded-md hover:opacity-90">
Register
</a>

<?php endif; ?>

</nav>

</div>

</header>



<main class="flex-grow">

<!-- ================= HERO ================= -->

<section class="max-w-7xl mx-auto px-6 py-24">

<div class="grid lg:grid-cols-2 gap-16 items-center">

<div>

<h1 class="text-4xl lg:text-5xl font-bold leading-tight mb-6">
Secure Milestone-Based Interior Project Management
</h1>

<p class="text-gray-600 text-lg mb-8 max-w-xl leading-relaxed">

Connect with professional interior designers and manage projects
through secure milestone payments, transparent bidding,
and structured approvals.

</p>

<div class="flex gap-4 flex-wrap">

<a href="<?php echo e(route('register')); ?>"
class="bg-black text-white px-6 py-3 rounded-md font-medium hover:opacity-90">
Start as Client
</a>

<a href="<?php echo e(route('register')); ?>?role=designer"
class="border border-black px-6 py-3 rounded-md font-medium hover:bg-black hover:text-white">
Start as Designer
</a>

<a href="<?php echo e(route('public.designers.index')); ?>"
class="border border-gray-300 px-6 py-3 rounded-md font-medium hover:bg-gray-100">
Browse Designers
</a>

</div>

</div>

<div class="bg-white rounded-xl shadow-lg overflow-hidden">

<img
src="https://images.unsplash.com/photo-1618221195710-dd6b41faaea6"
class="w-full h-[420px] object-cover"
alt="Interior Design">

</div>

</div>

</section>



<!-- ================= PLATFORM STATS ================= -->

<?php if(isset($stats)): ?>

<section class="bg-gray-100 py-16 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="grid md:grid-cols-4 gap-8 text-center">

<div class="bg-white p-6 rounded-lg shadow">
<p class="text-3xl font-bold text-blue-600">
<?php echo e($stats['designers']); ?>

</p>
<p class="text-sm text-gray-500 mt-2">Designers</p>
</div>

<div class="bg-white p-6 rounded-lg shadow">
<p class="text-3xl font-bold text-indigo-600">
<?php echo e($stats['projects']); ?>

</p>
<p class="text-sm text-gray-500 mt-2">Projects Posted</p>
</div>

<div class="bg-white p-6 rounded-lg shadow">
<p class="text-3xl font-bold text-emerald-600">
<?php echo e($stats['completed']); ?>

</p>
<p class="text-sm text-gray-500 mt-2">Completed Projects</p>
</div>

<div class="bg-white p-6 rounded-lg shadow">
<p class="text-3xl font-bold text-purple-600">
₹<?php echo e(number_format($stats['revenue'])); ?>

</p>
<p class="text-sm text-gray-500 mt-2">Platform Revenue</p>
</div>

</div>

</div>

</section>

<?php endif; ?>



<!-- ================= TOP RATED DESIGNERS ================= -->

<?php if(isset($topRated) && $topRated->count()): ?>

<section class="bg-white py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
🥇 Top Rated Designers
</h2>

<p class="text-gray-500">
Highest rated designers on our platform
</p>

</div>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

<?php $__currentLoopData = $topRated; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-gray-50 border rounded-xl p-6">

<h3 class="font-semibold text-lg flex items-center gap-2">
<?php echo e($designer->name); ?>


<?php if($designer->availabilityStatus() === 'online'): ?>
<span class="text-green-600 text-xs">🟢 Online</span>

<?php elseif($designer->availabilityStatus() === 'recent'): ?>
<span class="text-yellow-500 text-xs">🟡 Active</span>

<?php else: ?>
<span class="text-gray-400 text-xs">⚫ Offline</span>
<?php endif; ?>

</h3>

<p class="text-sm text-gray-500">
<?php echo e(ucfirst($designer->specialization ?? 'Interior Designer')); ?>

</p>

<p class="text-yellow-500 font-semibold mt-2">
⭐ <?php echo e(number_format($designer->received_reviews_avg_rating ?? 0, 1)); ?>/5
</p>

<a href="<?php echo e(route('public.designers.show',$designer->id)); ?>"
class="inline-block mt-3 text-blue-600 text-sm hover:underline">
View Profile →
</a>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>

<!-- ================= ONLINE DESIGNERS ================= -->

<?php if(isset($onlineDesigners) && $onlineDesigners->count()): ?>

<section class="bg-green-50 py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
🟢 Designers Online Right Now
</h2>

<p class="text-gray-500">
Currently active interior designers on the platform
</p>

</div>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

<?php $__currentLoopData = $onlineDesigners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-white border rounded-xl p-6">

<h3 class="font-semibold text-lg flex items-center gap-2">
<?php echo e($designer->name); ?>


<span class="text-green-600 text-xs">🟢 Online</span>

</h3>

<p class="text-sm text-gray-500">
<?php echo e(ucfirst($designer->specialization ?? 'Interior Designer')); ?>

</p>

<a href="<?php echo e(route('public.designers.show',$designer->id)); ?>"
class="inline-block mt-3 text-blue-600 text-sm hover:underline">
View Profile →
</a>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>

<!-- ================= TRENDING DESIGNERS ================= -->

<?php if(isset($trending) && $trending->count()): ?>

<section class="bg-gray-50 py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
🔥 Trending Designers
</h2>

<p class="text-gray-500">
Most active designers based on projects & reviews
</p>

</div>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

<?php $__currentLoopData = $trending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-white border rounded-xl p-6">

<h3 class="font-semibold text-lg flex items-center gap-2">
<?php echo e($designer->name); ?>


<?php if($designer->availabilityStatus() === 'online'): ?>
<span class="text-green-600 text-xs">🟢 Online</span>

<?php elseif($designer->availabilityStatus() === 'recent'): ?>
<span class="text-yellow-500 text-xs">🟡 Active</span>

<?php else: ?>
<span class="text-gray-400 text-xs">⚫ Offline</span>
<?php endif; ?>

</h3>

<p class="text-sm text-gray-500">
<?php echo e(ucfirst($designer->specialization ?? 'Interior Designer')); ?>

</p>

<a href="<?php echo e(route('public.designers.show',$designer->id)); ?>"
class="inline-block mt-3 text-blue-600 text-sm hover:underline">
View Profile →
</a>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>



<!-- ================= RISING TALENT DESIGNERS ================= -->

<?php if(isset($rising) && $rising->count()): ?>

<section class="bg-white py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
🚀 Rising Talent Designers
</h2>

<p class="text-gray-500">
New designers gaining popularity
</p>

</div>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

<?php $__currentLoopData = $rising; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-gray-50 border rounded-xl p-6">

<h3 class="font-semibold text-lg flex items-center gap-2">
<?php echo e($designer->name); ?>


<?php if($designer->availabilityStatus() === 'online'): ?>
<span class="text-green-600 text-xs">🟢 Online</span>

<?php elseif($designer->availabilityStatus() === 'recent'): ?>
<span class="text-yellow-500 text-xs">🟡 Active</span>

<?php else: ?>
<span class="text-gray-400 text-xs">⚫ Offline</span>
<?php endif; ?>

</h3>

<p class="text-sm text-gray-500">
<?php echo e(ucfirst($designer->specialization ?? 'Interior Designer')); ?>

</p>

<a href="<?php echo e(route('public.designers.show',$designer->id)); ?>"
class="inline-block mt-3 text-blue-600 text-sm hover:underline">
View Profile →
</a>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>

<!-- ================= RECOMMENDED DESIGNERS ================= -->

<?php if(isset($recommended) && $recommended->count()): ?>

<section class="bg-gray-50 py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
⭐ Recommended Designers
</h2>

<p class="text-gray-500">
Best performing designers based on rating and project success
</p>

</div>

<div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">

<?php $__currentLoopData = $recommended; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $designer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-white border rounded-xl p-6">

<h3 class="font-semibold text-lg flex items-center gap-2">
<?php echo e($designer->name); ?>


<?php if($designer->availabilityStatus() === 'online'): ?>
<span class="text-green-600 text-xs">🟢 Online</span>
<?php endif; ?>

</h3>

<p class="text-sm text-gray-500">
<?php echo e(ucfirst($designer->specialization ?? 'Interior Designer')); ?>

</p>

<p class="text-yellow-500 font-semibold mt-2">
⭐ <?php echo e(number_format($designer->received_reviews_avg_rating ?? 0,1)); ?>/5
<span class="text-xs text-gray-400">
(<?php echo e($designer->reviews_count ?? 0); ?> reviews)
</span>
</p>

<a href="<?php echo e(route('public.designers.show',$designer->id)); ?>"
class="inline-block mt-3 text-blue-600 text-sm hover:underline">
View Profile →
</a>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>

<!-- ================= LIVE ACTIVITY FEED ================= -->

<?php if(isset($activities) && $activities->count()): ?>

<section class="bg-gray-100 py-20 border-t">

<div class="max-w-5xl mx-auto px-6">

<div class="text-center mb-12">

<h2 class="text-3xl font-semibold mb-3">
🔥 Live Platform Activity
</h2>

<p class="text-gray-500">
Recent activity happening across the platform
</p>

</div>

<div class="space-y-4">

<?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="bg-white p-4 rounded-lg shadow flex justify-between items-center">

<div class="text-sm text-gray-700">

<strong><?php echo e($activity->user->name ?? 'User'); ?></strong>

<?php echo e($activity->description); ?>


<?php if(optional($activity->project)->title): ?>
<span class="text-blue-600">
(<?php echo e(optional($activity->project)->title); ?>)
</span>
<?php endif; ?>

</div>

<div class="text-xs text-gray-400">
<?php echo e($activity->created_at->diffForHumans()); ?>

</div>

</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

</div>

</section>

<?php endif; ?>

<!-- ================= FEATURES ================= -->

<section id="features" class="bg-white py-20 border-t">

<div class="max-w-7xl mx-auto px-6">

<div class="text-center mb-14">

<h2 class="text-3xl font-semibold mb-3">
Built for Structured Project Execution
</h2>

<p class="text-gray-500">
Professional lifecycle control with secure financial workflows.
</p>

</div>

<div class="grid md:grid-cols-3 gap-10">

<div class="p-6 bg-gray-50 rounded-lg border">
<h3 class="font-semibold mb-3">Milestone Escrow</h3>
<p class="text-sm text-gray-600">
Funds are secured before work begins and released after approval.
</p>
</div>

<div class="p-6 bg-gray-50 rounded-lg border">
<h3 class="font-semibold mb-3">Role Dashboards</h3>
<p class="text-sm text-gray-600">
Dedicated dashboards for Clients, Designers and Admin.
</p>
</div>

<div class="p-6 bg-gray-50 rounded-lg border">
<h3 class="font-semibold mb-3">Revenue Tracking</h3>
<p class="text-sm text-gray-600">
Automated commission and financial reporting.
</p>
</div>

</div>

</div>

</section>



<!-- ================= WORKFLOW ================= -->

<section id="workflow" class="py-20 bg-gray-50 border-t">

<div class="max-w-6xl mx-auto px-6 text-center">

<h2 class="text-3xl font-semibold mb-12">
How the Milestone Workflow Works
</h2>

<div class="grid md:grid-cols-3 gap-10">

<div>
<div class="text-3xl font-bold mb-4">1</div>
<h4 class="font-semibold mb-2">Bid & Assign</h4>
<p class="text-sm text-gray-600">
Designers submit proposals and clients choose the best fit.
</p>
</div>

<div>
<div class="text-3xl font-bold mb-4">2</div>
<h4 class="font-semibold mb-2">Fund Milestone</h4>
<p class="text-sm text-gray-600">
Clients fund each milestone securely before work begins.
</p>
</div>

<div>
<div class="text-3xl font-bold mb-4">3</div>
<h4 class="font-semibold mb-2">Release Payment</h4>
<p class="text-sm text-gray-600">
Admin verifies and releases funds to designers.
</p>
</div>

</div>

</div>

</section>



<!-- ================= CTA ================= -->

<section class="bg-black text-white py-20">

<div class="max-w-5xl mx-auto px-6 text-center">

<h2 class="text-3xl font-semibold mb-6">
Start Your Interior Design Project Today
</h2>

<p class="text-gray-300 mb-8">
Post a project or hire professional designers through our
secure milestone escrow platform.
</p>

<div class="flex justify-center gap-4 flex-wrap">

<a href="<?php echo e(route('register')); ?>"
class="bg-white text-black px-6 py-3 rounded-md font-medium hover:opacity-90">
Create Free Account
</a>

<a href="<?php echo e(route('public.designers.index')); ?>"
class="border border-white px-6 py-3 rounded-md hover:bg-white hover:text-black">
Browse Designers
</a>

</div>

</div>

</section>


</main>



<!-- ================= FOOTER ================= -->

<footer class="bg-gray-900 text-white text-center py-6 text-sm">

© <?php echo e(date('Y')); ?> Interior Design Portal (IDP)
Secure Milestone Escrow Platform.

</footer>

</body>
</html>
<?php /**PATH C:\wamp64\www\IDP\resources\views/welcome.blade.php ENDPATH**/ ?>